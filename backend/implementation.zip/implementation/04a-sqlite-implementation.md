# SQLite Implementation

This document covers the implementation details for setting up and working with SQLite in the Go crypto trading bot.

## 1. SQLite Setup

SQLite provides a lightweight, file-based database solution that's perfect for the trading bot implementation.

### 1.1 Installing the SQLite Driver

Add the SQLite driver to your project:

```bash
go get github.com/mattn/go-sqlite3
go get github.com/jmoiron/sqlx
```

> Note: `go-sqlite3` is a CGO-enabled package, so a C compiler must be installed on your system.

### 1.2 Database Connection Management

Create a connection management package:

```go
// internal/platform/database/sqlite.go
package database

import (
    "fmt"
    "log"
    "os"
    "time"

    "github.com/jmoiron/sqlx"
    _ "github.com/mattn/go-sqlite3" // SQLite driver
)

// Config holds database configuration
type Config struct {
    Path            string
    MaxOpenConns    int
    MaxIdleConns    int
    ConnMaxLifetime time.Duration
    BusyTimeout     string
}

// NewSQLiteDB creates a new SQLite database connection
func NewSQLiteDB(config Config) (*sqlx.DB, error) {
    // Ensure the database directory exists
    dbDir := os.path.Dir(config.Path)
    if err := os.MkdirAll(dbDir, 0755); err != nil {
        return nil, fmt.Errorf("failed to create database directory: %w", err)
    }

    // Create DSN with busy timeout to prevent "database is locked" errors
    dsn := fmt.Sprintf("%s?_busy_timeout=%s&_journal_mode=WAL&_foreign_keys=on", 
                      config.Path, config.BusyTimeout)

    // Open database connection
    db, err := sqlx.Open("sqlite3", dsn)
    if err != nil {
        return nil, fmt.Errorf("failed to open database: %w", err)
    }

    // Configure connection pool
    db.SetMaxOpenConns(config.MaxOpenConns)
    db.SetMaxIdleConns(config.MaxIdleConns)
    db.SetConnMaxLifetime(config.ConnMaxLifetime)

    // Verify connection
    if err := db.Ping(); err != nil {
        return nil, fmt.Errorf("failed to ping database: %w", err)
    }

    log.Printf("Connected to SQLite database at %s", config.Path)
    return db, nil
}

// DefaultConfig returns a sensible default configuration
func DefaultConfig(dbPath string) Config {
    return Config{
        Path:            dbPath,
        MaxOpenConns:    10,
        MaxIdleConns:    5,
        ConnMaxLifetime: 1 * time.Hour,
        BusyTimeout:     "5000", // 5 seconds
    }
}
```

## 2. Transaction Management

Implement utility functions for transaction management:

```go
// internal/platform/database/transaction.go
package database

import (
    "context"
    "fmt"

    "github.com/jmoiron/sqlx"
)

// RunInTransaction executes a function within a transaction
func RunInTransaction(ctx context.Context, db *sqlx.DB, fn func(*sqlx.Tx) error) error {
    tx, err := db.BeginTxx(ctx, nil)
    if err != nil {
        return fmt.Errorf("failed to begin transaction: %w", err)
    }

    // Defer a rollback in case anything fails
    defer func() {
        if p := recover(); p != nil {
            _ = tx.Rollback()
            panic(p) // Re-throw panic after rollback
        } else if err != nil {
            _ = tx.Rollback() // Only rollback if error is non-nil
        }
    }()

    // Execute the transaction function
    if err = fn(tx); err != nil {
        return err // Will trigger rollback in defer
    }

    // Commit the transaction
    if err = tx.Commit(); err != nil {
        return fmt.Errorf("failed to commit transaction: %w", err)
    }

    return nil
}
```

## 3. Database Initialization in Main

In the main application entry point, initialize the database connection:

```go
// cmd/server/main.go
package main

import (
    "log"
    "os"
    "path/filepath"
    "time"

    "github.com/ryanlisse/cryptobot-backend/internal/platform/database"
    "github.com/ryanlisse/cryptobot-backend/internal/domain/repository"
)

func main() {
    // Determine database path
    dataDir := os.Getenv("DATA_DIR")
    if dataDir == "" {
        homeDir, err := os.UserHomeDir()
        if err != nil {
            log.Fatalf("Failed to get user home directory: %v", err)
        }
        dataDir = filepath.Join(homeDir, ".cryptobot")
    }

    dbPath := filepath.Join(dataDir, "cryptobot.db")
    
    // Create database configuration
    dbConfig := database.DefaultConfig(dbPath)
    
    // Initialize database connection
    db, err := database.NewSQLiteDB(dbConfig)
    if err != nil {
        log.Fatalf("Failed to initialize database: %v", err)
    }
    defer db.Close()
    
    // Run migrations
    if err := database.RunMigrations(db); err != nil {
        log.Fatalf("Failed to run migrations: %v", err)
    }
    
    // Create repository factory
    repoFactory := repository.NewFactory(db)
    
    // Continue with application initialization...
}
```

## 4. Performance Considerations

For optimal SQLite performance in the trading bot:

### 4.1 Journal Mode

We use WAL (Write-Ahead Logging) journal mode for better concurrency:

```go
dsn := fmt.Sprintf("%s?_journal_mode=WAL", dbPath)
```

### 4.2 Busy Timeout

Set an appropriate busy timeout to handle concurrent access:

```go
dsn := fmt.Sprintf("%s?_busy_timeout=5000", dbPath) // 5 seconds
```

### 4.3 Connection Pooling

Configure the connection pool based on your application's needs:

```go
db.SetMaxOpenConns(10)   // Maximum number of open connections
db.SetMaxIdleConns(5)    // Maximum number of idle connections
db.SetConnMaxLifetime(1 * time.Hour) // Maximum connection lifetime
```

### 4.4 Foreign Key Constraints

Enable foreign key constraints for data integrity:

```go
dsn := fmt.Sprintf("%s?_foreign_keys=on", dbPath)
```

## 5. Troubleshooting

### 5.1 "Database is locked" Errors

If you encounter "database is locked" errors:

1. Ensure you're closing all transactions properly
2. Increase the busy timeout in the DSN
3. Check that you're properly closing all database connections
4. Consider using the WAL journal mode (as we've done above)
5. Reduce concurrent write operations if possible

### 5.2 Performance Issues

For performance issues:

1. Add appropriate indexes to frequently queried columns
2. Use prepared statements for repeated queries
3. Keep transactions as short as possible
4. Consider using bulk operations for multiple inserts
5. Monitor your connection pool usage

Next steps:
- Continue to [04b-sqlite-migrations.md](04b-sqlite-migrations.md) for database migration implementation
- See [04c-repository-implementations.md](04c-repository-implementations.md) for concrete repository implementations
